import 'package:flutter/material.dart';

void main() => runApp(HitungLuasApp());

class HitungLuasApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hitung Luas App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.grey,
        fontFamily: 'Roboto',
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hitung Luas App'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            _buildModernButton(
              context,
              text: 'HITUNG LUAS PERSEGI',
              color: const Color.fromARGB(255, 206, 193, 193),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => LuasPersegiPage()),
              ),
            ),
            _buildModernButton(
              context,
              text: 'HITUNG LUAS LINGKARAN',
              color: const Color.fromARGB(255, 189, 200, 189),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => LuasLingkaranPage()),
              ),
            ),
            _buildModernButton(
              context,
              text: 'PROFILE DEVELOPER',
              color: const Color.fromARGB(255, 199, 183, 199),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfileDeveloperPage()),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModernButton(BuildContext context,
      {required String text, required Color color, required VoidCallback onPressed}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10.0),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
        ),
        onPressed: onPressed,
        child: Text(
          text,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}

// Halaman Hitung Luas Persegi
class LuasPersegiPage extends StatelessWidget {
  final TextEditingController panjangController = TextEditingController();
  final TextEditingController lebarController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hitung Luas Persegi'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            _buildTextField(
              controller: panjangController,
              label: 'Panjang (m)',
            ),
            _buildTextField(
              controller: lebarController,
              label: 'Lebar (m)',
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
              ),
              onPressed: () {
                final double panjang = double.tryParse(panjangController.text) ?? 0;
                final double lebar = double.tryParse(lebarController.text) ?? 0;
                final double luas = panjang * lebar;
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    content: Text('Luas: ${luas.toStringAsFixed(2)} m²'),
                  ),
                );
              },
              child: const Text('Hitung', style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({required TextEditingController controller, required String label}) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: TextField(
        controller: controller,
        keyboardType: TextInputType.number,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
        ),
      ),
    );
  }
}

// Halaman Hitung Luas Lingkaran

class LuasLingkaranPage extends StatelessWidget {
  final TextEditingController jariJariController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hitung Luas Lingkaran'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            _buildTextField(
              controller: jariJariController,
              label: 'Jari-jari (m)',
            ),
            const SizedBox(height: 16.0),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 14.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
              ),
              onPressed: () {
                _hitungLuas(context);
              },
              child: const Text('Hitung', style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({required TextEditingController controller, required String label}) {
    return TextField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
      ),
    );
  }

  void _hitungLuas(BuildContext context) {
    if (jariJariController.text.isEmpty) {
      _showErrorDialog(context, 'Jari-jari tidak boleh kosong.');
      return;
    }

    final double? jariJari = double.tryParse(jariJariController.text);
    if (jariJari == null || jariJari <= 0) {
      _showErrorDialog(context, 'Masukkan angka valid untuk jari-jari.');
      return;
    }

    final double luas = 3.14 * jariJari * jariJari;
    _showResultDialog(context, 'Luas lingkaran adalah ${luas.toStringAsFixed(2)} m²');
  }

  void _showErrorDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _showResultDialog(BuildContext context, String result) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hasil Perhitungan'),
        content: Text(result),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}


// Halaman Profile Developer
class ProfileDeveloperPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1D1E33),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const CircleAvatar(
              radius: 80.0,
              backgroundImage: AssetImage('assets/img/mine.jpg'),
            ),
            const Text(
              'Muhammad Napis',
              style: TextStyle(
                fontSize: 28.0,
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
            const Text(
              'Developer & Designer',
              style: TextStyle(
                fontSize: 16.0,
                color: Colors.tealAccent,
              ),
            ),
            const SizedBox(height: 20.0),
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              child: ListTile(
                leading: const Icon(Icons.person, color: Colors.teal),
                title: const Text('2210020004'),
              ),
            ),
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              child: ListTile(
                leading: const Icon(Icons.class_, color: Colors.teal),
                title: const Text('5A non reg BJM'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
