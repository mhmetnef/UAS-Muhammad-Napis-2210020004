// This is a basic Flutter widget test.
//
// To perform an interaction with a widget in your test, use the WidgetTester
// utility in the flutter_test package. For example, you can send tap and scroll
// gestures. You can also use WidgetTester to find child widgets in the widget
// tree, read text, and verify that the values of widget properties are correct.

import 'package:cardprofile/main.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('Calculates rectangle area', (WidgetTester tester) async {
    await tester.pumpWidget(HitungLuasApp());

    // Navigasi ke halaman hitung luas persegi
    final persegiButton = find.text('HITUNG LUAS PERSEGI');
    await tester.tap(persegiButton);
    await tester.pumpAndSettle();

    // Input panjang dan lebar
    final panjangField = find.byType(TextField).at(0);
    final lebarField = find.byType(TextField).at(1);
    await tester.enterText(panjangField, '5');
    await tester.enterText(lebarField, '3');

    // Klik tombol hitung
    final hitungButton = find.text('Hitung');
    await tester.tap(hitungButton);
    await tester.pumpAndSettle();

    // Verifikasi hasil
    expect(find.text('Luas: 15.00 m²'), findsOneWidget);

    // Tutup dialog hasil
    final okButton = find.text('OK');
    await tester.tap(okButton);
    await tester.pumpAndSettle();
  });

  testWidgets('Calculates circle area', (WidgetTester tester) async {
    await tester.pumpWidget(HitungLuasApp());

    // Navigasi ke halaman hitung luas lingkaran
    final lingkaranButton = find.text('HITUNG LUAS LINGKARAN');
    await tester.tap(lingkaranButton);
    await tester.pumpAndSettle();

    // Input jari-jari
    final jariJariField = find.byType(TextField).first;
    await tester.enterText(jariJariField, '7');

    // Klik tombol hitung
    final hitungButton = find.text('Hitung');
    await tester.tap(hitungButton);
    await tester.pumpAndSettle();

    // Verifikasi hasil
    expect(find.text('Luas lingkaran adalah 153.86 m²'), findsOneWidget);

    // Tutup dialog hasil
    final okButton = find.text('OK');
    await tester.tap(okButton);
    await tester.pumpAndSettle();
  });

  testWidgets('Displays developer profile', (WidgetTester tester) async {
    await tester.pumpWidget(HitungLuasApp());

    // Navigasi ke halaman profil developer
    final profileButton = find.text('PROFILE DEVELOPER');
    await tester.tap(profileButton);
    await tester.pumpAndSettle();

    // Verifikasi informasi profil
    expect(find.text('Muhammad Napis'), findsOneWidget);
    expect(find.text('2210020004'), findsOneWidget);
    expect(find.text('5A non reg BJM'), findsOneWidget);
  });
}

